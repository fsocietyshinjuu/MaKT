Mouse and Keyboard Test 1.2.0
Run it from a terminal or your file manager:  ./MouseKeyboardTest
(If it does not start, make it executable first:  chmod +x MouseKeyboardTest)
It opens in Google Chrome, Chromium, Microsoft Edge or Brave as a standalone window, so one of them must be installed.
Developer: Shinjuu (fsociety.shinjuu@gmail.com)
