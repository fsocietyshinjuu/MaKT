Mouse and Keyboard Test 1.2.2
Drag "Mouse and Keyboard Test.app" to Applications. The first time, right-click it, choose Open, then Open again (the app is not signed by Apple).
It opens in Google Chrome, Microsoft Edge or Brave as a standalone window, so one of them must be installed.
Developer: Shinjuu (fsociety.shinjuu@gmail.com)
