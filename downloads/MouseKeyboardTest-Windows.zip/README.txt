Mouse and Keyboard Test 1.2.2
Double-click "Mouse and Keyboard Test.exe". It opens in Microsoft Edge (or Google Chrome) as a standalone window.
Windows may show an "unknown publisher" warning the first time: choose More info, then Run anyway.
Developer: Shinjuu (fsociety.shinjuu@gmail.com)
